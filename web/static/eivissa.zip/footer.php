                	<div class="clear"></div>
				</div>
			</div>
		</div>
		<div class="clear"></div>
		<div id="footer" class="">
			<div class="footer-inner">
				<div class="misc misc-logo2"></div>
				<ul>
					<li><a href="terms.php">Terminos y licencia</a></li>
					<li><a href="#">Mapa del sitio</a></li>
					<li><a href="form_contact.php">Contactanos</a></li>
					<li><a href="#">RSS Suscriure <span class="misc misc-rss2 inline"></span></a></li>
					<li><a href="#">RSS Opinions <span class="misc misc-rss2 inline"></span></a></li>
				</ul>
				<div class="misc misc-logo3"></div>
			</div>
		</div>

		<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
		<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/plugins/jquery-ui/js/jquery-ui-1.8.11.custom.min.js"></script>
		<script type="text/javascript" src="js/main.js"></script>

	</body>
</html>