	
	<?
	$reg = array('text-shadow', 'box-shadow', 'border-radius', 'opacity');
	if($_POST['css']){
		@preg_match_all("/((".implode('|', $reg).")\:[^\;]+)/i", $_POST['css'], $m);
		var_dump($m);
	}
	?>
	
	<style>
		textarea{width:800px; height:120px; display:block; }
	</style>
	
	<form method="post">
		<textarea name="css"><?=$_POST['css']?></textarea>
		<button>Dale</button>
	</form>