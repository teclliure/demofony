<?
    $pageId = '';
    include_once('header.php');
?>

	<div class="box no-tabs no-margin">
		<div class="box-content show">
	
			<div class="box-title">
				<p>Términos y Licencia</p>
			</div>
			
			<div class="">
				Contenido...
			</div>
			
		</div>
	</div>
	
	<? include_once('footer.php'); ?>
